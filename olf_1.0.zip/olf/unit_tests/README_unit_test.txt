Oracle Logging Framework
Copyright (c) 2011 - 2012 AppsDBA Consulting. All rights reserved.

This file is part of the Oracle Logging Framework.

The Oracle Logging Framework is free software: you can redistribute
it and/or modify it under the terms of the GNU Lesser Public License
as published by the Free Software Foundation, either version 3 of
the License, or (at your option) any later version.

The Oracle Logging Framework is distributed in the hope that it will
be useful, but WITHOUT ANY WARRANTY; without even the implied
warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
See the GNU Lesser Public License for more details.

You should have received a copy of the GNU Lesser Public License
along with the Oracle Logging Framework.
If not, see <http://www.gnu.org/licenses/>.

$Revision$
$Date$

OLF Unit Test README

The OLF unit test requires the utplsql22 package available from http://http://utplsql.sourceforge.net/

To run the OLF unit test the ut_dblog package must be installed in the OLF schema. The source
is available in the "unit_tests" directory. To install connect to the OLF schema and run the
following:

SQL> @ut_dblog.pks
SQL> @ut_dblog.pkb

Once installed the following can be run connected to the OLF schema:

set serveroutput on;
exec utplsql.test ('dblog', recompile_in => FALSE);

