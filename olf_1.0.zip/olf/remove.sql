PROMPT --- This script removes the OLF user and public synonyms.
PROMPT --- It requires access to a DBA account.
PROMPT
PROMPT --- Please exit this script (using Control-C or break) if you
PROMPT --- do not wish to continue.
PROMPT
PROMPT --- Press [Return] to continue.
--
ACCEPT oraans
--
PROMPT
--
ACCEPT olf_usr CHAR DEFAULT 'olf' PROMPT 'Enter the userid for the OLF account [olf]:  '
--
PROMPT You are about to remove the OLF schema and objects...
PROMPT
PROMPT --- Press [Return] to continue.
--
ACCEPT oraans
--
PROMPT Dropping the OLF schema owner &&olf_usr
DROP USER &&olf_usr CASCADE;
--
PROMPT ... Dropping DBLOG context
DROP CONTEXT dblog_ctx;
--
PROMPT ... Dropping PUBLIC synonyms on DBLOG packages and tables
DROP PUBLIC SYNONYM dblog;
DROP PUBLIC SYNONYM dblog_utils;
DROP PUBLIC SYNONYM dblog_log;
DROP PUBLIC SYNONYM dblog_config;
--
EXIT;
