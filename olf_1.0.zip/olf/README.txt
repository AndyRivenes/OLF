Oracle Logging Framework
Copyright (c) 2011 - 2012 AppsDBA Consulting. All rights reserved.

This file is part of the Oracle Logging Framework.

The Oracle Logging Framework is free software: you can redistribute
it and/or modify it under the terms of the GNU Lesser Public License
as published by the Free Software Foundation, either version 3 of
the License, or (at your option) any later version.

The Oracle Logging Framework is distributed in the hope that it will
be useful, but WITHOUT ANY WARRANTY; without even the implied
warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
See the GNU Lesser Public License for more details.

You should have received a copy of the GNU Lesser Public License
along with the Oracle Logging Framework.
If not, see <http://www.gnu.org/licenses/>.

$Revision: 339 $
$Date: 2012-11-29 23:08:45 -0800 (Thu, 29 Nov 2012) $

See the OLF User Guide in the documentation directory for a full
explanation of how to install and use the OLF.

Install guide for the OLF:

 1. Create an "olf" directory on the database server under 
    $ORACLE_BASE/local (e.g. /u01/app/oracle/local/olf) or
    some other suitable directory.

 2. Untar the olf tar file into the $ORACLE_BASE/local/olf
    directory.
 
    $ cd $ORACLE_BASE/local/olf
    $ tar xvf ../olf.tar

 3. Connect as a SYSDBA account and run the install.sql script.

 4. For ILO support run the ilo_timer_v23.pkb script connected
    as the ILO schema owner.

    NOTE: The ilo_timer package has been tested with the latest
          version of the ILO which is 2.3.

          A bug has been found in the ILO 2.3 ilo_task package
          that causes tracing to never be disabled once it has
          been enabled. Run the ilo_task_v23.pkb script to
          fix this bug. This has been reported to Method-R.

 5. To run the unit tests the utPLSQL package must be installed.
    It is available at http://utplsql.sourceforge.net/.

 

