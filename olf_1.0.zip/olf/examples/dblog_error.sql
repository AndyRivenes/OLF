--
-- $Revision: 249 $
-- $Date: 2012-04-25 23:18:03 -0700 (Wed, 25 Apr 2012) $
--
set serveroutput on;
declare
  l_num number;
begin
  ilo_task.begin_task(
    module => 'module',
    action => 'action');
  --
  select 1 into l_num from dual;
  --
  ilo_task.end_task;
exception
  when others then
    dblog.error('dblog.error test message');
    --
    ilo_task.end_all_tasks;
    RAISE;
end;
/

