--
-- $Revision: 309 $
-- $Date: 2012-09-11 20:06:07 -0700 (Tue, 11 Sep 2012) $
--
set serveroutput on;
declare
  l_num number;
begin
  dbms_application_info.set_module(module_name=>'module',action_name=>'action');
  --
  dblog.info('Before statement');
  select 1 into l_num from dual;
  dblog.info('After statement');
  --
  dbms_application_info.set_module(module_name=>NULL,action_name=>NULL);
exception
  when others then
    dblog.error('Error message');
    --
    dbms_application_info.set_module(module_name=>NULL,action_name=>NULL);
end;
/
