--
-- $Revision: 218 $
-- $Date: 2012-04-11 21:36:05 -0700 (Wed, 11 Apr 2012) $
--
set serveroutput on;
declare
  l_num number;
begin
  ilo_task.begin_task(
    module => 'module',
    action => 'action');
  --
  dblog.info('Before statement');
  select 1 into l_num from dual;
  dblog.info('After statement');
  --
  ilo_task.end_task;
end;
/
