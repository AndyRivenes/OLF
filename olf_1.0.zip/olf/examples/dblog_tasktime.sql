--
-- $Revision: 351 $
-- $Date: 2012-12-01 20:12:12 -0800 (Sat, 01 Dec 2012) $
--
set serveroutput on;
declare
  l_time number;
begin
  ilo_task.begin_task(
    module => 'module',
    action => 'action');
  --
  l_time := DBMS_UTILITY.GET_TIME;
  dbms_lock.sleep(5);
  --
  dblog.set_task_time(
    p_tasktime => DBMS_UTILITY.GET_TIME - l_time,
    p_text => 'Set task time');
  --
  ilo_task.end_task;
end;
/
