--
-- $Revision: 289 $
-- $Date: 2012-09-07 22:09:24 -0700 (Fri, 07 Sep 2012) $
--
begin
  ilo_task.begin_task(
    module => 'module',
    action => 'action');
end;
/

