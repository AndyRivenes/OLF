--
-- $Revision$
-- $Date$
--
set serveroutput on;
--
begin
  dblog.help;
end;
/


