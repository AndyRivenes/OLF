--
-- $Revision: 309 $
-- $Date: 2012-09-11 20:06:07 -0700 (Tue, 11 Sep 2012) $
--
set serveroutput on;
declare
  l_num number;
begin
  ilo_task.begin_task(
    module => 'module',
    action => 'action');
  --
  select 1 into l_num from dummy;
  --
  ilo_task.end_task;
exception
  when others then
    dblog.fatal('dblog.fatal test message');
    --
    ilo_task.end_all_tasks;
    RAISE;
end;
/

