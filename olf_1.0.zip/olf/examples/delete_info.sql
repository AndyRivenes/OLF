--
-- $Revision: 199 $
-- $Date: 2012-04-06 21:32:37 -0700 (Fri, 06 Apr 2012) $
--
delete from dblog_settings;
commit;

