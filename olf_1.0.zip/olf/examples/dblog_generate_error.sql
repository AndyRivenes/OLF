--
-- $Revision$
-- $Date$
--
set serveroutput on;
declare
  l_num number;
begin
  ilo_task.begin_task(
    module => 'module',
    action => 'action');
  --
  select col1 into l_num from dummy;
  --
  ilo_task.end_task;
exception
  when others then
    dblog.error('dblog.error test message');
    --
    ilo_task.end_all_tasks;
    RAISE;
end;
/

