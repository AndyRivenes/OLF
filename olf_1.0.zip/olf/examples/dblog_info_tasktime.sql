--
-- $Revision: 351 $
-- $Date: 2012-12-01 20:12:12 -0800 (Sat, 01 Dec 2012) $
--
set serveroutput on;
declare
  l_num pls_integer;
begin
  ilo_task.begin_task(
    module => 'tasktime',
    action => 'test',
    comment => 'Task1',
    begin_time => systimestamp);
  --
  dblog.info('Before statement');
  select 1 into l_num from dual;
  dbms_lock.sleep(5);
  dblog.info('After statement');
  --
  ilo_task.end_task(
    end_time => systimestamp);
end;
/
