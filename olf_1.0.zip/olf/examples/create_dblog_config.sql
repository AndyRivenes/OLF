--
-- $Revision$
-- $Date$
--
begin
  dblog_utils.create_dblog_config;
end;
/

