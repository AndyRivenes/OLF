--
-- $Revision: 309 $
-- $Date: 2012-09-11 20:06:07 -0700 (Tue, 11 Sep 2012) $
--
truncate table dblog_log;
