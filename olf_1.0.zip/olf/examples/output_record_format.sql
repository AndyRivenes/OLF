col username heading 'USER' format a6;
col datetime format a28;
col module_name heading 'MODULE' format a6;
col action_name heading 'ACTION' format a6;
col log_level heading 'LEVEL' format a5;
col object_name format a22;
col line_no heading 'LINE' format 999;
col text format a16;
--
select
  username
  , datetime
  , module_name
  , action_name
  , log_level
  , object_name
  , line_no
  , text
from
  dblog_log
order by
  logid
/

