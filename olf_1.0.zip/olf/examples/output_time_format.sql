set linesize 150;
col username heading 'USER' format a6;
col datetime format a28;
col module_name heading 'MODULE' format a6;
col action_name heading 'ACTION' format a6;
col log_level heading 'LEVEL' format a5;
col object_name format a22;
col tasktime heading 'Task|Time' format 9999.999999;
col text format a16;
--
select
  username
  , datetime
  , module_name
  , action_name
  , log_level
  , object_name
  , tasktime
  , text
from
  dblog_log
order by
  logid
/
