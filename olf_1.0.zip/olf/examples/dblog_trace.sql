--
-- $Revision: 309 $
-- $Date: 2012-09-11 20:06:07 -0700 (Tue, 11 Sep 2012) $
--
declare
  l_num number;
begin
  ilo_task.begin_task(
    module => 'module',
    action => 'action');
  --
  dbms_output.put_line('Is trace enabled: ' || dblog.IS_TRACE_ENABLED );
  --
  ilo_task.end_task;
end;
/
