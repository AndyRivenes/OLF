--
-- $Revision: 309 $
-- $Date: 2012-09-11 20:06:07 -0700 (Tue, 11 Sep 2012) $
--
declare
  l_num number;
begin
  ilo_task.begin_task(
    module => 'module',
    action => 'action');
  --
  dblog.info('Before statement');
  select 1 into l_num from dual;
  dblog.info('After statement');
  --
  ilo_task.end_task;
exception
  when others then
    dblog.error('Error message');
    --
    ilo_task.end_all_tasks;
end;
/
