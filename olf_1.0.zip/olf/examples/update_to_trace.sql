--
-- $Revision: 310 $
-- $Date: 2012-09-11 21:26:39 -0700 (Tue, 11 Sep 2012) $
--
update dblog_config set trace_enabled = 'Y'
where module_name = 'module'
and action_name = 'action';
commit;

