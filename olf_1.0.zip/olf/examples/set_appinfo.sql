begin
  dbms_application_info.set_module(module_name=>'module',action_name=>'action');
end;
/
exit;
