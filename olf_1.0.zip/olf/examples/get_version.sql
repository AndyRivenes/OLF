--
-- $Revision: 289 $
-- $Date: 2012-09-07 22:09:24 -0700 (Fri, 07 Sep 2012) $
--
select dblog.get_version from dual;

