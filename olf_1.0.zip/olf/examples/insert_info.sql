--
-- $Revision: 310 $
-- $Date: 2012-09-11 21:26:39 -0700 (Tue, 11 Sep 2012) $
--
insert into dblog_config values(1,'module','action',null,null,null,'INFO','N');
commit;

