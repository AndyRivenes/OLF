REM  Oracle Logging Framework
REM  Copyright (c) 2011 - 2012 AppsDBA Consulting. All rights reserved.
REM
REM  This file is part of the Oracle Logging Framework.
REM
REM  The Oracle Logging Framework is free software: you can redistribute
REM  it and/or modify it under the terms of the GNU Lesser Public License
REM  as published by the Free Software Foundation, either version 3 of
REM  the License, or (at your option) any later version.
REM
REM  The Oracle Logging Framework is distributed in the hope that it will
REM  be useful, but WITHOUT ANY WARRANTY; without even the implied
REM  warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
REM  See the GNU Lesser Public License for more details.
REM
REM  You should have received a copy of the GNU Lesser Public License
REM  along with the Oracle Logging Framework.
REM  If not, see <http://www.gnu.org/licenses/>.
REM
REM
REM $Revision: 346 $
REM $Date: 2012-12-01 14:13:02 -0800 (Sat, 01 Dec 2012) $
REM

BEGIN
  dblog_utils.create_dblog_config;
END;
/
