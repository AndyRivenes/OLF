PROMPT --- This script creates the OLF user and installs the OLF code.
PROMPT --- It requires access to a DBA account.
PROMPT
PROMPT --- Please exit this script (using Control-C or break) if you
PROMPT --- do not wish to continue.
PROMPT
PROMPT --- Press [Return] to continue.
--
ACCEPT oraans
--
PROMPT
--
ACCEPT olf_usr CHAR DEFAULT 'olf' PROMPT 'Enter the userid for the OLF account [olf]:  '
--
PROMPT
--
ACCEPT olf_pwd CHAR DEFAULT 'olf' HIDE PROMPT 'Enter the password for the OLF account [olf]:  '
--
PROMPT
--
ACCEPT olf_ts CHAR DEFAULT 'users' PROMPT 'Enter the tablespace for the OLF account [users]:  '
--
PROMPT
--
ACCEPT olf_temp CHAR DEFAULT 'temp' PROMPT 'Enter the temporary tablespace for the OLF account [temp]:  '
--
PROMPT Creating the new OLF schema owner &&olf_usr...
PROMPT
--
-- CREATE TABLESPACE olftab;
-- datafile '/home/oracle/app/oracle/oradata/orcl/olftab01.dbf'
-- size 10m autoextend on next 10m maxsize 100m;
--
CREATE USER &&olf_usr
IDENTIFIED BY &&olf_pwd
DEFAULT TABLESPACE &&olf_ts
TEMPORARY TABLESPACE &&olf_temp
PROFILE DEFAULT
ACCOUNT UNLOCK;
--
ALTER USER &&olf_usr DEFAULT ROLE ALL;
ALTER USER &&olf_usr QUOTA UNLIMITED ON &&olf_ts;
--
GRANT CREATE SESSION TO &&olf_usr;
GRANT CREATE PROCEDURE TO &&olf_usr;
GRANT EXECUTE ON dbms_session TO &&olf_usr;
GRANT EXECUTE ON dbms_lock TO &&olf_usr;
--
-- NOTE: These privileges can be revoked after the install
--
GRANT CREATE TABLE TO &&olf_usr;
GRANT CREATE SEQUENCE TO &&olf_usr;
GRANT CREATE TRIGGER TO &&olf_usr;
GRANT CREATE PUBLIC SYNONYM TO &&olf_usr;
--
--
DROP CONTEXT dblog_ctx;
CREATE CONTEXT dblog_ctx USING olf.dblog;
--
--
REM Ensure you can connect to the OLF account using the password given
--
CONNECT &olf_usr/&olf_pwd
--
PROMPT -- If the previous connect failed, please exit this script
PROMPT -- (using Control-C or break) and restart, otherwise press [Return]
ACCEPT answer
--
--
SPOOL olf_install.log;
SET SERVEROUTPUT on;
--
WHENEVER SQLERROR EXIT;
--
PROMPT ... Installing DBLOG Package Spec
@dblog.pks
--
PROMPT ... Installing DBLOG Package Body
@dblog.pkb
--
PROMPT ... Installing DBLOG_UTILS Package Spec
@dblog_utils.pks
--
PROMPT ... Installing DBLOG_UTILS Package Body
@dblog_utils.pkb
--
PROMPT ... Creating DBLOG log table
@dblog_log_tab.sql
--
PROMPT ... Creating DBLOG config table
@dblog_config_table.sql
--
PROMPT ... Granting EXECUTE on DBLOG packages to PUBLIC
GRANT EXECUTE ON dblog TO PUBLIC;
GRANT EXECUTE ON dblog_utils TO PUBLIC;
--
WHENEVER SQLERROR CONTINUE;
--
PROMPT ... Creating PUBLIC synonyms on DBLOG packages and tables
DROP PUBLIC SYNONYM dblog;
CREATE PUBLIC SYNONYM dblog FOR olf.dblog;
--
DROP PUBLIC SYNONYM dblog_utils;
CREATE PUBLIC SYNONYM dblog_utils FOR olf.dblog_utils;
--
DROP PUBLIC SYNONYM dblog_log;
CREATE PUBLIC SYNONYM dblog_log FOR olf.dblog_log;
--
DROP PUBLIC SYNONYM dblog_config;
CREATE PUBLIC SYNONYM dblog_config FOR olf.dblog_config;
--
EXIT;
